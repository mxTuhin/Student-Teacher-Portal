package com.scorpionsstudio.studentteacherportal;

public class StaticVars {

    public static String name="Default name";
    public static String email="Default Email";
}
