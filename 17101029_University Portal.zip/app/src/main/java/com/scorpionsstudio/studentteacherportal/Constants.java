package com.scorpionsstudio.studentteacherportal;

public class Constants {

    public static String baseURL = "http://103.148.26.234/stp/";
    public static String loginURL = baseURL+"login.php";
    public static String registerURL = baseURL+"register.php";


}
